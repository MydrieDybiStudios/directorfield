import asyncio
import pygame
import random
import math
import json
import os
import sys
from enum import Enum
from datetime import datetime

# Для генерации отчётов (не работает в браузере)
try:
    from fpdf import FPDF
    PDF_AVAILABLE = False if sys.platform == 'emscripten' else True
except ImportError:
    PDF_AVAILABLE = False
    if sys.platform != 'emscripten':
        print("Для генерации отчётов установите fpdf2: pip install fpdf2")

# ================== Константы ==================
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
FPS = 60

# Цвета (глубокая, современная палитра)
COLOR_BG_TOP = (25, 35, 55)
COLOR_BG_BOTTOM = (10, 15, 25)
COLOR_PANEL = (40, 50, 70)
COLOR_PANEL_LIGHT = (70, 85, 110)
COLOR_TEXT = (240, 245, 255)
COLOR_TEXT_DARK = (160, 170, 190)
COLOR_BUTTON = (80, 140, 220)
COLOR_BUTTON_HOVER = (120, 180, 255)
COLOR_BUTTON_DISABLED = (70, 80, 100)
COLOR_WELL_ACTIVE = (80, 230, 80)
COLOR_WELL_IDLE = (250, 220, 70)
COLOR_WELL_ACCIDENT = (250, 70, 70)
COLOR_WELL_ABANDONED = (130, 130, 130)
COLOR_ZONE_OIL = (70, 140, 230, 200)
COLOR_ZONE_GAS = (230, 140, 70, 200)
COLOR_ZONE_WATER = (70, 90, 230, 200)
COLOR_ZONE_BORDER = (200, 220, 255, 150)
COLOR_GRAPH = (100, 200, 250)
COLOR_GRAPH_BG = (30, 35, 45)
COLOR_COMPETITOR = (250, 100, 100)
COLOR_SHADOW = (0, 0, 0, 120)
COLOR_GOLD = (255, 215, 0)

# Настройки сложности
DIFFICULTY = {
    'easy':   {'budget': 200_000_000, 'oil_price': 65, 'event_chance': 0.4,
               'win_budget': 400_000_000, 'num_competitors': 1, 'tax_rate': 0.2,
               'interest_rate': 0.05, 'fine_mult': 0.5, 'research_cost': 5_000_000},
    'medium': {'budget': 120_000_000, 'oil_price': 55, 'event_chance': 0.5,
               'win_budget': 700_000_000, 'num_competitors': 2, 'tax_rate': 0.25,
               'interest_rate': 0.08, 'fine_mult': 1.0, 'research_cost': 8_000_000},
    'hard':   {'budget': 100_000_000, 'oil_price': 50, 'event_chance': 0.6,
               'win_budget': 900_000_000, 'num_competitors': 3, 'tax_rate': 0.28,
               'interest_rate': 0.1,  'fine_mult': 1.3, 'research_cost': 10_000_000}
}

# Достижения
ACHIEVEMENTS = {
    'first_well': {"name": "Первая скважина", "desc": "Пробурить первую скважину", "unlocked": False},
    'ten_wells': {"name": "Буровой магнат", "desc": "Пробурить 10 скважин", "unlocked": False},
    'millionaire': {"name": "Миллионер", "desc": "Накопить 1 млн руб.", "unlocked": False},
    'billionaire': {"name": "Миллиардер", "desc": "Накопить 1 млрд руб.", "unlocked": False},
    'eco_friendly': {"name": "Эколог", "desc": "Достичь эко-рейтинга 150", "unlocked": False},
    'monopolist': {"name": "Монополист", "desc": "Занять все зоны", "unlocked": False},
}

# ================== Перечисления ==================
class GameState(Enum):
    MENU = 1
    PLAYING = 2
    PAUSED = 3
    GAME_OVER = 4
    WIN = 5
    SETTINGS = 6
    ACHIEVEMENTS = 7
    ZONE_DETAIL = 8
    RESEARCH = 9
    INFRASTRUCTURE = 10
    EMPLOYEES = 11

class WellStatus(Enum):
    ACTIVE = 1
    IDLE = 2
    ACCIDENT = 3
    ABANDONED = 4

class WellCompletion(Enum):
    FOUNTAIN = 1
    ESP = 2
    SRP = 3
    GASLIFT = 4

class ZoneType(Enum):
    OIL = 1
    GAS = 2
    WATER = 3

class EmployeeType(Enum):
    GEOLOGIST = 1
    ENGINEER = 2
    MANAGER = 3

# ================== Классы данных ==================
class Well:
    def __init__(self, well_id, name, pos, zone_type=ZoneType.OIL, completion=WellCompletion.FOUNTAIN,
                 is_fracked=False, status=WellStatus.ACTIVE, owner='player'):
        self.id = well_id
        self.name = name
        self.pos = pos
        self.zone_type = zone_type
        self.status = status
        self.completion = completion
        self.is_fracked = is_fracked
        self.owner = owner
        self.oil_rate = 500.0
        self.water_cut = 0.0
        self.reservoir_pressure = 25.0
        self.initial_pressure = 25.0
        self.total_oil = 0.0
        self.opex = 200_000.0
        self.oil_history = []
        self.water_history = []
        self.animation_offset = random.uniform(0, 2*math.pi)
        self.gas_flare = random.choice([True, False])

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'pos': self.pos,
            'zone_type': self.zone_type.value,
            'status': self.status.value,
            'completion': self.completion.value,
            'is_fracked': self.is_fracked,
            'owner': self.owner,
            'oil_rate': self.oil_rate,
            'water_cut': self.water_cut,
            'reservoir_pressure': self.reservoir_pressure,
            'initial_pressure': self.initial_pressure,
            'total_oil': self.total_oil,
            'opex': self.opex,
            'oil_history': self.oil_history,
            'water_history': self.water_history,
            'gas_flare': self.gas_flare
        }

    @classmethod
    def from_dict(cls, data):
        well = cls(data['id'], data['name'], tuple(data['pos']), ZoneType(data['zone_type']))
        well.status = WellStatus(data['status'])
        well.completion = WellCompletion(data['completion'])
        well.is_fracked = data['is_fracked']
        well.owner = data.get('owner', 'player')
        well.oil_rate = data['oil_rate']
        well.water_cut = data['water_cut']
        well.reservoir_pressure = data['reservoir_pressure']
        well.initial_pressure = data['initial_pressure']
        well.total_oil = data['total_oil']
        well.opex = data['opex']
        well.oil_history = data['oil_history']
        well.water_history = data['water_history']
        well.gas_flare = data.get('gas_flare', False)
        return well

class Zone:
    def __init__(self, rect, zone_type, reserves, pressure, risk, water_risk, biome):
        self.rect = rect
        self.zone_type = zone_type
        self.potential_reserves = reserves
        self.initial_pressure = pressure
        self.risk_factor = risk
        self.water_risk = water_risk
        self.biome = biome
        self.color = {
            ZoneType.OIL: COLOR_ZONE_OIL,
            ZoneType.GAS: COLOR_ZONE_GAS,
            ZoneType.WATER: COLOR_ZONE_WATER
        }.get(zone_type, COLOR_ZONE_OIL)
        self.pulse = 0
        self.wells = []
        self.surface = self.create_surface()

    def create_surface(self):
        w, h = self.rect.w, self.rect.h
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        base_color = self.color[:3]
        for y in range(h):
            alpha_factor = 0.7 + 0.3 * math.sin(y / h * math.pi)
            alpha = int(self.color[3] * alpha_factor)
            color = (*base_color, alpha)
            pygame.draw.line(surf, color, (0, y), (w, y))
        for _ in range(5):
            x = random.randint(0, w-1)
            y = random.randint(0, h-1)
            pygame.draw.circle(surf, (*base_color, 100), (x, y), random.randint(3, 7))
        return surf

    def update_pulse(self, animations_enabled):
        if animations_enabled:
            self.pulse = (self.pulse + 0.02) % (2*math.pi)

class Economy:
    def __init__(self, budget=100_000_000, oil_price=60.0, tax_rate=0.3, eco_score=100.0, difficulty='medium'):
        self.budget = budget
        self.oil_price = oil_price
        self.tax_rate = tax_rate
        self.eco_score = eco_score
        self.fixed_costs = 1_500_000
        self.loan = 0
        self.loan_interest = DIFFICULTY[difficulty]['interest_rate']
        self.fine_mult = DIFFICULTY[difficulty]['fine_mult']
        self.total_fines = 0
        self.total_taxes = 0
        self.total_interest = 0
        self.profit_history = []
        self.tech_level = 1
        self.research_cost = DIFFICULTY[difficulty]['research_cost']
        self.infrastructure = 0
        self.oil_price_trend = 0
        self.market_shock_timer = 0

    def to_dict(self):
        return {
            'budget': self.budget,
            'oil_price': self.oil_price,
            'tax_rate': self.tax_rate,
            'eco_score': self.eco_score,
            'fixed_costs': self.fixed_costs,
            'loan': self.loan,
            'loan_interest': self.loan_interest,
            'fine_mult': self.fine_mult,
            'total_fines': self.total_fines,
            'total_taxes': self.total_taxes,
            'total_interest': self.total_interest,
            'profit_history': self.profit_history,
            'tech_level': self.tech_level,
            'research_cost': self.research_cost,
            'infrastructure': self.infrastructure,
            'oil_price_trend': self.oil_price_trend,
            'market_shock_timer': self.market_shock_timer
        }

    @classmethod
    def from_dict(cls, data, difficulty='medium'):
        eco = cls(data['budget'], data['oil_price'], data['tax_rate'], data['eco_score'])
        eco.fixed_costs = data.get('fixed_costs', 1_500_000)
        eco.loan = data.get('loan', 0)
        eco.loan_interest = data.get('loan_interest', DIFFICULTY[difficulty]['interest_rate'])
        eco.fine_mult = data.get('fine_mult', DIFFICULTY[difficulty]['fine_mult'])
        eco.total_fines = data.get('total_fines', 0)
        eco.total_taxes = data.get('total_taxes', 0)
        eco.total_interest = data.get('total_interest', 0)
        eco.profit_history = data.get('profit_history', [])
        eco.tech_level = data.get('tech_level', 1)
        eco.research_cost = data.get('research_cost', DIFFICULTY[difficulty]['research_cost'])
        eco.infrastructure = data.get('infrastructure', 0)
        eco.oil_price_trend = data.get('oil_price_trend', 0)
        eco.market_shock_timer = data.get('market_shock_timer', 0)
        return eco

class Loan:
    def __init__(self, amount, months, interest_rate):
        self.amount = amount
        self.months = months
        self.interest_rate = interest_rate
        self.monthly_payment = amount * (1 + interest_rate) / months

class Competitor:
    def __init__(self, name, color, aggression):
        self.name = name
        self.color = color
        self.aggression = aggression
        self.budget = random.randint(50_000_000, 150_000_000)
        self.wells = []

    def act(self, zones, all_wells, game):
        if random.random() < self.aggression and self.budget > 10_000_000:
            free_zones = [z for z in zones if not any(w.owner == self.name for w in z.wells)]
            if free_zones:
                zone = random.choice(free_zones)
                cost = random.randint(8_000_000, 15_000_000)
                if self.budget >= cost:
                    self.budget -= cost
                    well_id = random.randint(1000, 9999)
                    well = Well(well_id, f"{self.name}-{well_id}",
                                (zone.rect.centerx + random.randint(-20,20),
                                 zone.rect.centery + random.randint(-20,20)),
                                zone.zone_type,
                                random.choice(list(WellCompletion)),
                                random.choice([True, False]),
                                WellStatus.ACTIVE,
                                self.name)
                    zone.wells.append(well)
                    self.wells.append(well)
                    all_wells.append(well)
                    return well
        return None

class GameEvent:
    def __init__(self, name, desc, choices):
        self.name = name
        self.desc = desc
        self.choices = choices

class Research:
    def __init__(self, name, cost, effect_desc, effect_func):
        self.name = name
        self.cost = cost
        self.effect_desc = effect_desc
        self.effect_func = effect_func
        self.researched = False

    def to_dict(self):
        return {
            'name': self.name,
            'cost': self.cost,
            'effect_desc': self.effect_desc,
            'researched': self.researched
        }

    @classmethod
    def from_dict(cls, data):
        r = cls(data['name'], data['cost'], data['effect_desc'], None)
        r.researched = data['researched']
        return r

class Infrastructure:
    def __init__(self, name, cost, effect):
        self.name = name
        self.cost = cost
        self.effect = effect
        self.built = False

    def to_dict(self):
        return {'name': self.name, 'cost': self.cost, 'built': self.built}

    @classmethod
    def from_dict(cls, data):
        inf = cls(data['name'], data['cost'], None)
        inf.built = data['built']
        return inf

class Employee:
    def __init__(self, name, emp_type, skill, salary):
        self.name = name
        self.type = emp_type
        self.skill = skill
        self.salary = salary
        self.hired = False

    def to_dict(self):
        return {
            'name': self.name,
            'type': self.type.value,
            'skill': self.skill,
            'salary': self.salary,
            'hired': self.hired
        }

    @classmethod
    def from_dict(cls, data):
        emp = cls(data['name'], EmployeeType(data['type']), data['skill'], data['salary'])
        emp.hired = data['hired']
        return emp

# ================== Класс кнопки с анимацией ==================
class Button:
    def __init__(self, rect, text, callback, font_size=24, color=COLOR_BUTTON, hover_color=COLOR_BUTTON_HOVER, tooltip=""):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.font = pygame.font.Font(None, font_size)
        self.color = color
        self.hover_color = hover_color
        self.hovered = False
        self.click_anim = 0
        self.tooltip = tooltip

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.click_anim = 5
                self.callback()

    def update(self):
        if self.click_anim > 0:
            self.click_anim -= 1

    def draw(self, screen):
        shadow_rect = self.rect.move(4, 4)
        pygame.draw.rect(screen, COLOR_SHADOW, shadow_rect, border_radius=10)
        if self.click_anim > 0:
            rect = self.rect.inflate(-4, -4)
        else:
            rect = self.rect
        color = self.hover_color if self.hovered else self.color
        pygame.draw.rect(screen, color, rect, border_radius=10)
        pygame.draw.rect(screen, COLOR_TEXT, rect, 2, border_radius=10)
        text_surf = self.font.render(self.text, True, COLOR_TEXT)
        text_rect = text_surf.get_rect(center=rect.center)
        screen.blit(text_surf, text_rect)
        if self.hovered and self.tooltip:
            tip = pygame.font.Font(None, 18).render(self.tooltip, True, COLOR_TEXT)
            tip_rect = tip.get_rect(topleft=(rect.x, rect.y - 25))
            pygame.draw.rect(screen, COLOR_PANEL, tip_rect.inflate(10, 5), border_radius=5)
            screen.blit(tip, tip_rect)

# ================== Генератор событий ==================
class EventManager:
    def __init__(self, difficulty='medium'):
        self.event_chance = DIFFICULTY[difficulty]['event_chance']
        self.events = self.create_events()

    def create_events(self):
        return [
            GameEvent("Авария на скважине", "Произошёл выброс газа на одной из скважин.",
                      [("Закрыть скважину", -2_000_000, 0.0, -5, "Скважина закрыта, потери минимальны."),
                       ("Продолжить работу", -5_000_000, 0.8, -20, "Авария усилилась, скважина повреждена.")]),
            GameEvent("Рост цен на нефть", "ОПЕК+ сократил добычу, цены растут.",
                      [("Продать больше", 0, 1.15, 0, "Цена выросла на 15%"),
                       ("Законтрактоваться", 0, 0.9, 0, "Стабильность, но рост меньше")]),
            GameEvent("Экологическая проверка", "Пришла проверка Росприроднадзора.",
                      [("Заплатить штраф", -3_000_000, 1.0, 0, "Отделались лёгким испугом"),
                       ("Оспорить", 0, 1.0, -15, "Штраф увеличен, рейтинг упал")]),
            GameEvent("Новая технология", "Учёные предложили новый метод повышения нефтеотдачи.",
                      [("Инвестировать", -8_000_000, 1.2, 5, "Дебит всех скважин увеличен!"),
                       ("Отказаться", 0, 1.0, 0, "Пока не до инноваций.")]),
            GameEvent("Забастовка рабочих", "Рабочие требуют повышения зарплаты.",
                      [("Повысить зарплату", -4_000_000, 1.0, 0, "Рабочие довольны."),
                       ("Отказать", 0, 0.9, -10, "Производительность упала.")]),
            GameEvent("Порыв трубопровода", "Нефтепровод повреждён, утечка.",
                      [("Быстрый ремонт", -6_000_000, 1.0, -10, "Утечка устранена."),
                       ("Тщательная ликвидация", -10_000_000, 1.0, 5, "Всё чисто.")]),
            GameEvent("Кредитное предложение", "Банк предлагает кредит на развитие.",
                      [("Взять 50 млн под 10%", 50_000_000, 1.0, 0, "Кредит получен."),
                       ("Отказаться", 0, 1.0, 0, "Нет кредита.")]),
            GameEvent("Инвестиции в инфраструктуру", "Государство софинансирует строительство дорог.",
                      [("Принять", -3_000_000, 1.0, 2, "Инфраструктура улучшена, OPEX снижен."),
                       ("Отказаться", 0, 1.0, 0, "Возможность упущена.")]),
            GameEvent("Конкурент обанкротился", "Один из конкурентов разорился и продаёт активы.",
                      [("Выкупить скважины", -20_000_000, 1.2, 0, "Вы получили несколько скважин."),
                       ("Пропустить", 0, 1.0, 0, "Ничего не произошло.")]),
            GameEvent("Макроэкономический шок", "Неожиданный кризис на мировых рынках.",
                      [("Сократить инвестиции", 0, 0.9, -5, "Добыча упала, но вы сохранили капитал."),
                       ("Игнорировать", -10_000_000, 1.0, -10, "Потери из-за падения цен.")]),
        ]

    def get_random_event(self):
        if random.random() < self.event_chance:
            return random.choice(self.events)
        return None

# ================== Генерация карты с биомами ==================
def generate_zones(width, height, num_zones=8):
    zones = []
    biomes = ['forest', 'desert', 'tundra', 'water']
    for _ in range(num_zones):
        w = random.randint(100, 180)
        h = random.randint(100, 180)
        x = random.randint(50, width - w - 50)
        y = random.randint(100, height - 200)
        zone_type = random.choices([ZoneType.OIL, ZoneType.GAS, ZoneType.WATER], weights=[0.6, 0.3, 0.1])[0]
        reserves = random.randint(2000, 15000)
        pressure = random.uniform(15, 40)
        risk = random.uniform(0.05, 0.4)
        water_risk = random.uniform(0.1, 0.9)
        biome = random.choice(biomes)
        zones.append(Zone(pygame.Rect(x, y, w, h), zone_type, reserves, pressure, risk, water_risk, biome))
    return zones

def generate_relief_with_biomes(width, height, cell_size=10):
    cols = width // cell_size + 1
    rows = height // cell_size + 1
    relief = [[0.0] * cols for _ in range(rows)]
    biomes = [[0] * cols for _ in range(rows)]
    hills = []
    for _ in range(10):
        cx = random.uniform(0, cols)
        cy = random.uniform(0, rows)
        radius = random.uniform(5, 20)
        height_hill = random.uniform(0.3, 0.8)
        hills.append((cx, cy, radius, height_hill))
    for y in range(rows):
        for x in range(cols):
            h = 0.2
            for (cx, cy, r, amp) in hills:
                dist = math.sqrt((x - cx)**2 + (y - cy)**2)
                if dist < r:
                    factor = (r - dist) / r
                    h += amp * factor * 0.8
            h += random.uniform(-0.1, 0.1)
            h = max(0.0, min(1.0, h))
            relief[y][x] = h
            if h < 0.2:
                biome = 4
            elif h < 0.4:
                biome = 0
            elif h < 0.6:
                biome = random.choice([1, 2])
            elif h < 0.8:
                biome = 3
            else:
                biome = 1
            biomes[y][x] = biome
    return relief, biomes, cell_size

def draw_relief_with_biomes(screen, relief_map, biome_map, cell_size):
    colors = {
        0: (100, 140, 80),
        1: (34, 139, 34),
        2: (238, 203, 173),
        3: (224, 255, 255),
        4: (65, 105, 225)
    }
    for y in range(len(relief_map) - 1):
        for x in range(len(relief_map[0]) - 1):
            color = colors.get(biome_map[y][x], (100, 100, 100))
            rect = pygame.Rect(x * cell_size, y * cell_size, cell_size, cell_size)
            pygame.draw.rect(screen, color, rect)

# ================== Функции генерации PDF (отключены в браузере) ==================
def generate_certificate(game, player_name="Игрок", filename="certificate.pdf"):
    if not PDF_AVAILABLE or sys.platform == 'emscripten':
        return None
    try:
        pdf = FPDF()
        pdf.add_page()
        font_path = "DejaVuSans.ttf"
        if os.path.exists(font_path):
            pdf.add_font("DejaVu", "", font_path, uni=True)
            pdf.set_font("DejaVu", "", 16)
            use_cyrillic = True
        else:
            pdf.set_font("Helvetica", "", 16)
            use_cyrillic = False
        pdf.set_draw_color(100, 150, 200)
        pdf.set_line_width(2)
        pdf.rect(10, 10, 190, 277)
        pdf.cell(0, 40, "CERTIFICATE" if not use_cyrillic else "СЕРТИФИКАТ", align="C", ln=1)
        pdf.set_font_size(14)
        pdf.cell(0, 20, "This is to certify that" if not use_cyrillic else "Награждается", align="C", ln=1)
        pdf.set_font_size(18)
        pdf.cell(0, 20, player_name, align="C", ln=1)
        pdf.set_font_size(14)
        pdf.cell(0, 20, "for successfully completing the game" if not use_cyrillic else "за успешное прохождение игры", align="C", ln=1)
        pdf.cell(0, 20, "\"Oil Field Director\"", align="C", ln=1)
        pdf.cell(0, 20, f"at {game.difficulty} difficulty", align="C", ln=1)
        pdf.cell(0, 20, f"Final budget: {game.economy.budget:,.0f} RUB", align="C", ln=1)
        pdf.set_font_size(12)
        pdf.cell(0, 30, f"Date: {datetime.now().strftime('%d.%m.%Y')}", align="C", ln=1)
        pdf.output(filename)
        return filename
    except Exception as e:
        print(f"Ошибка создания сертификата: {e}")
        return None

def generate_detailed_report(game, filename="report.pdf"):
    if not PDF_AVAILABLE or sys.platform == 'emscripten':
        return None
    try:
        pdf = FPDF()
        pdf.add_page()
        font_path = "DejaVuSans.ttf"
        if os.path.exists(font_path):
            pdf.add_font("DejaVu", "", font_path, uni=True)
            pdf.set_font("DejaVu", "", 16)
            use_cyrillic = True
        else:
            pdf.set_font("Helvetica", "", 16)
            use_cyrillic = False
        pdf.cell(0, 20, "Detailed Game Report" if not use_cyrillic else "Детальный отчёт по игре", align="C", ln=1)
        pdf.set_font_size(12)
        pdf.cell(0, 10, f"Date: {datetime.now().strftime('%d.%m.%Y %H:%M')}", ln=1)
        pdf.cell(0, 10, f"Difficulty: {game.difficulty}", ln=1)
        pdf.cell(0, 10, f"Final Budget: {game.economy.budget:,.0f} RUB", ln=1)
        pdf.cell(0, 10, f"Total Oil Produced: {sum(w.total_oil for w in game.wells if w.owner=='player'):,.0f} t", ln=1)
        pdf.cell(0, 10, f"Wells: {len([w for w in game.wells if w.owner=='player'])}", ln=1)
        pdf.cell(0, 10, f"Taxes Paid: {game.economy.total_taxes:,.0f} RUB", ln=1)
        pdf.cell(0, 10, f"Fines: {game.economy.total_fines:,.0f} RUB", ln=1)
        pdf.cell(0, 10, f"Interest Paid: {game.economy.total_interest:,.0f} RUB", ln=1)
        pdf.cell(0, 10, f"Eco Score: {game.economy.eco_score:.0f}", ln=1)
        pdf.cell(0, 10, f"Tech Level: {game.economy.tech_level}", ln=1)
        pdf.cell(0, 10, f"Infrastructure: {game.economy.infrastructure}", ln=1)
        pdf.cell(0, 10, "", ln=1)
        pdf.set_font("Helvetica", "B", 14)
        pdf.cell(0, 10, "Profit History (last 24 months):", ln=1)
        pdf.set_font("Helvetica", "", 10)
        for i, profit in enumerate(game.economy.profit_history[-24:]):
            pdf.cell(0, 6, f"Month {i+1}: {profit:,.0f} RUB", ln=1)
        pdf.output(filename)
        return filename
    except Exception as e:
        print(f"Ошибка создания отчёта: {e}")
        return None

# ================== Класс для сохранения настроек ==================
class Settings:
    def __init__(self):
        self.sound_enabled = True
        self.animations_enabled = True
        self.game_speed = 1
        self.show_relief = True
        self.load()

    def load(self):
        try:
            with open("settings.json", 'r') as f:
                data = json.load(f)
                self.sound_enabled = data.get('sound_enabled', True)
                self.animations_enabled = data.get('animations_enabled', True)
                self.game_speed = data.get('game_speed', 1)
                self.show_relief = data.get('show_relief', True)
        except:
            pass

    def save(self):
        data = {
            'sound_enabled': self.sound_enabled,
            'animations_enabled': self.animations_enabled,
            'game_speed': self.game_speed,
            'show_relief': self.show_relief
        }
        with open("settings.json", 'w') as f:
            json.dump(data, f)

# ================== Основной класс игры ==================
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Директор месторождения")
        self.clock = pygame.time.Clock()
        self.running = True
        self.state = GameState.MENU
        self.difficulty = 'medium'
        self.settings = Settings()

        pygame.mixer.init()
        self.sounds = {}
        self.load_sounds()

        try:
            self.font = pygame.font.Font("Roboto-Regular.ttf", 24)
            self.big_font = pygame.font.Font("Roboto-Regular.ttf", 36)
            self.small_font = pygame.font.Font("Roboto-Regular.ttf", 20)
        except:
            self.font = pygame.font.Font(None, 24)
            self.big_font = pygame.font.Font(None, 36)
            self.small_font = pygame.font.Font(None, 20)

        self.zones = []
        self.wells = []
        self.economy = None
        self.event_manager = None
        self.competitors = []
        self.date_year = 2025
        self.date_month = 1
        self.next_well_id = 1
        self.message_log = []
        self.game_over_reason = ""
        self.win_target = 0
        self.active_loans = []
        self.achievements = ACHIEVEMENTS.copy()

        self.researches = []
        self.infrastructure_objects = []
        self.employees = []
        self.available_employees = []

        self.buttons = []
        self.drilling_mode = False
        self.current_selected_well = None
        self.well_panel_open = False
        self.drilling_window_open = False
        self.current_drilling_zone = None
        self.drilling_window_pos = (0, 0)
        self.event_window_open = False
        self.current_event = None
        self.graph_window_open = False
        self.graph_well = None
        self.loan_window_open = False
        self.achievements_window_open = False
        self.research_window_open = False
        self.infrastructure_window_open = False
        self.employees_window_open = False

        self.loan_window_just_opened = False
        self.event_window_just_opened = False
        self.research_window_just_opened = False
        self.infrastructure_window_just_opened = False
        self.employees_window_just_opened = False

        self.drill_well_type = 0
        self.drill_completion = 0
        self.drill_frack = False
        self.drill_research = False

        self.relief_map = None
        self.biome_map = None
        self.relief_cell_size = 10
        self.camera_offset = [0, 0]
        self.camera_zoom = 1.0
        self.dragging = False
        self.drag_start = (0, 0)

        self.current_zone = None

        self.init_menu()

    def load_sounds(self):
        # В браузере используем .ogg, на десктопе .wav
        ext = '.ogg' if sys.platform == 'emscripten' else '.wav'
        sound_files = {
            'click': 'sfx/click' + ext,
            'drill': 'sfx/drill' + ext,
            'event': 'sfx/event' + ext,
            'win': 'sfx/win' + ext,
            'lose': 'sfx/lose' + ext
        }
        for name, fname in sound_files.items():
            if os.path.exists(fname):
                self.sounds[name] = pygame.mixer.Sound(fname)

    def play_sound(self, name):
        if self.settings.sound_enabled and name in self.sounds:
            self.sounds[name].play()

    # ================== Методы камеры ==================
    def world_to_screen(self, world_x, world_y):
        screen_x = (world_x + self.camera_offset[0]) * self.camera_zoom
        screen_y = (world_y + self.camera_offset[1]) * self.camera_zoom
        return int(screen_x), int(screen_y)

    def screen_to_world(self, screen_x, screen_y):
        world_x = screen_x / self.camera_zoom - self.camera_offset[0]
        world_y = screen_y / self.camera_zoom - self.camera_offset[1]
        return world_x, world_y

    # ================== Методы инициализации меню и игры ==================
    def init_menu(self):
        self.menu_buttons = []
        btn_width, btn_height = 250, 60
        cx = SCREEN_WIDTH // 2 - btn_width // 2

        if self.wells:
            self.menu_buttons.append(Button((cx, 140, btn_width, btn_height), "Продолжить", self.continue_game, 32, tooltip="Вернуться к текущей игре"))
            offset = 80
        else:
            offset = 0

        self.menu_buttons.append(Button((cx, 200 + offset, btn_width, btn_height), "Новая игра", self.new_game, 32, tooltip="Начать новую игру"))
        self.menu_buttons.append(Button((cx, 280 + offset, btn_width, btn_height), "Загрузить", self.load_game_menu, 32, tooltip="Загрузить сохранение"))
        self.menu_buttons.append(Button((cx, 360 + offset, btn_width, btn_height), "Настройки", self.open_settings, 32, tooltip="Настройки игры"))
        self.menu_buttons.append(Button((cx, 440 + offset, btn_width, btn_height), "Выход", self.quit_game, 32, tooltip="Выйти из игры"))

        self.diff_buttons = []
        diff_y_base = 300 + offset
        self.diff_buttons.append(Button((cx-150, diff_y_base, 120, 50), "Лёгкая", lambda: self.start_game('easy'), 24, tooltip="Большой бюджет, редкие события"))
        self.diff_buttons.append(Button((cx, diff_y_base, 120, 50), "Средняя", lambda: self.start_game('medium'), 24, tooltip="Сбалансированный режим"))
        self.diff_buttons.append(Button((cx+150, diff_y_base, 120, 50), "Сложная", lambda: self.start_game('hard'), 24, tooltip="Маленький бюджет, частые события"))
        self.show_diff_buttons = False

        self.settings_buttons = []
        set_y_base = 200 + offset
        self.settings_buttons.append(Button((cx, set_y_base, 250, 50), f"Звук: {'Вкл' if self.settings.sound_enabled else 'Выкл'}", self.toggle_sound, 28, tooltip="Включить/выключить звук"))
        self.settings_buttons.append(Button((cx, set_y_base+70, 250, 50), f"Анимации: {'Вкл' if self.settings.animations_enabled else 'Выкл'}", self.toggle_animations, 28, tooltip="Включить/выключить анимации"))
        self.settings_buttons.append(Button((cx, set_y_base+140, 250, 50), f"Скорость: {self.settings.game_speed}x", self.cycle_speed, 28, tooltip="Скорость игры"))
        self.settings_buttons.append(Button((cx, set_y_base+210, 250, 50), f"Рельеф: {'Вкл' if self.settings.show_relief else 'Выкл'}", self.toggle_relief, 28, tooltip="Показать/скрыть рельеф"))
        self.settings_buttons.append(Button((cx, set_y_base+280, 250, 50), "Назад", self.close_settings, 28, tooltip="Вернуться в меню"))

    def new_game(self):
        self.play_sound('click')
        self.show_diff_buttons = True

    def start_game(self, difficulty):
        self.play_sound('click')
        self.difficulty = difficulty
        self.state = GameState.PLAYING
        self.show_diff_buttons = False
        self.init_game()

    def continue_game(self):
        self.play_sound('click')
        self.state = GameState.PLAYING
        self.drilling_mode = False
        self.well_panel_open = False
        self.drilling_window_open = False
        self.event_window_open = False
        self.graph_window_open = False
        self.loan_window_open = False
        self.achievements_window_open = False
        self.research_window_open = False
        self.infrastructure_window_open = False
        self.employees_window_open = False
        self.current_selected_well = None
        self.current_event = None
        self.current_drilling_zone = None
        self.graph_well = None
        self.current_zone = None
        self.loan_window_just_opened = False
        self.event_window_just_opened = False
        self.research_window_just_opened = False
        self.infrastructure_window_just_opened = False
        self.employees_window_just_opened = False

    def open_settings(self):
        self.play_sound('click')
        self.state = GameState.SETTINGS

    def close_settings(self):
        self.play_sound('click')
        self.settings.save()
        self.state = GameState.MENU

    def toggle_sound(self):
        self.settings.sound_enabled = not self.settings.sound_enabled
        for btn in self.settings_buttons:
            if "Звук" in btn.text:
                btn.text = f"Звук: {'Вкл' if self.settings.sound_enabled else 'Выкл'}"

    def toggle_animations(self):
        self.settings.animations_enabled = not self.settings.animations_enabled
        for btn in self.settings_buttons:
            if "Анимации" in btn.text:
                btn.text = f"Анимации: {'Вкл' if self.settings.animations_enabled else 'Выкл'}"

    def cycle_speed(self):
        speeds = [1, 2, 3]
        idx = speeds.index(self.settings.game_speed) if self.settings.game_speed in speeds else 0
        self.settings.game_speed = speeds[(idx + 1) % len(speeds)]
        for btn in self.settings_buttons:
            if "Скорость" in btn.text:
                btn.text = f"Скорость: {self.settings.game_speed}x"

    def toggle_relief(self):
        self.settings.show_relief = not self.settings.show_relief
        for btn in self.settings_buttons:
            if "Рельеф" in btn.text:
                btn.text = f"Рельеф: {'Вкл' if self.settings.show_relief else 'Выкл'}"

    def init_game(self):
        diff = DIFFICULTY[self.difficulty]
        self.economy = Economy(budget=diff['budget'], oil_price=diff['oil_price'],
                               tax_rate=diff['tax_rate'], difficulty=self.difficulty)
        self.event_manager = EventManager(self.difficulty)
        self.win_target = diff['win_budget']
        self.zones = generate_zones(SCREEN_WIDTH, SCREEN_HEIGHT, num_zones=8)
        self.relief_map, self.biome_map, self.relief_cell_size = generate_relief_with_biomes(SCREEN_WIDTH, SCREEN_HEIGHT, cell_size=10)
        self.wells = []
        self.date_year = 2025
        self.date_month = 1
        self.next_well_id = 1
        self.message_log = ["Добро пожаловать! Начните бурение."]
        self.game_over_reason = ""
        self.active_loans = []
        self.achievements = ACHIEVEMENTS.copy()
        self.camera_offset = [0, 0]
        self.camera_zoom = 1.0
        self.current_zone = None

        self.init_researches()
        self.init_infrastructure()
        self.init_employees()

        self.competitors = []
        comp_names = ["Газпром", "Роснефть", "Лукойл"]
        for i in range(diff['num_competitors']):
            comp = Competitor(comp_names[i], COLOR_COMPETITOR, random.uniform(0.2, 0.6))
            self.competitors.append(comp)

        self.create_game_buttons()

    def init_researches(self):
        self.researches = [
            Research("Улучшенное бурение", 5_000_000, "Снижает риск аварий на 20%",
                     lambda g: [setattr(z, 'risk_factor', z.risk_factor * 0.8) for z in g.zones]),
            Research("Эффективные насосы", 8_000_000, "Увеличивает дебит на 15%",
                     lambda g: [setattr(w, 'oil_rate', w.oil_rate * 1.15) for w in g.wells if w.owner=='player']),
            Research("Экологичные технологии", 6_000_000, "Снижает штрафы на 30%",
                     lambda g: setattr(g.economy, 'fine_mult', g.economy.fine_mult * 0.7)),
            Research("Глубокая переработка", 10_000_000, "Позволяет продавать газ, увеличивая доход",
                     lambda g: None),
        ]

    def init_infrastructure(self):
        self.infrastructure_objects = [
            Infrastructure("Дороги", 10_000_000, "opex -5%"),
            Infrastructure("Трубопровод", 15_000_000, "opex -10%"),
            Infrastructure("Электростанция", 20_000_000, "opex -15%"),
        ]

    def init_employees(self):
        self.available_employees = [
            Employee("Иван Петров", EmployeeType.GEOLOGIST, 0.7, 500_000),
            Employee("Мария Сидорова", EmployeeType.ENGINEER, 0.8, 600_000),
            Employee("Пётр Иванов", EmployeeType.MANAGER, 0.6, 400_000),
        ]
        self.employees = []

    def create_game_buttons(self):
        self.buttons = []
        self.buttons.append(Button((SCREEN_WIDTH-220, 20, 200, 40), "След. месяц", self.next_month, tooltip="Перейти к следующему месяцу"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 70, 200, 40), "Бурить", self.enter_drilling_mode, tooltip="Выбрать зону для бурения"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 120, 200, 40), "Банк", self.open_loan_window, tooltip="Взять кредит"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 170, 200, 40), "НИОКР", self.open_research_window, tooltip="Исследования"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 220, 200, 40), "Стройка", self.open_infrastructure_window, tooltip="Построить инфраструктуру"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 270, 200, 40), "Персонал", self.open_employees_window, tooltip="Нанять сотрудников"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 320, 200, 40), "Достижения", self.open_achievements, tooltip="Просмотреть достижения"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 370, 200, 40), "Отчёт", self.generate_report_pdf, tooltip="Создать PDF-отчёт"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 420, 200, 40), "Сертификат", self.generate_certificate_pdf, tooltip="Получить сертификат"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 470, 200, 40), "Сохранить", self.save_game, tooltip="Сохранить игру"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 520, 200, 40), "Загрузить", self.load_game, tooltip="Загрузить игру"))
        self.buttons.append(Button((SCREEN_WIDTH-220, 570, 200, 40), "Меню", self.return_to_menu, tooltip="Вернуться в главное меню"))

    def open_research_window(self):
        self.play_sound('click')
        self.research_window_open = True
        self.research_window_just_opened = True

    def open_infrastructure_window(self):
        self.play_sound('click')
        self.infrastructure_window_open = True
        self.infrastructure_window_just_opened = True

    def open_employees_window(self):
        self.play_sound('click')
        self.employees_window_open = True
        self.employees_window_just_opened = True

    def research(self, index):
        if index >= len(self.researches) or self.researches[index].researched:
            return
        research = self.researches[index]
        if self.economy.budget >= research.cost:
            self.economy.budget -= research.cost
            research.researched = True
            if research.effect_func:
                research.effect_func(self)
            self.add_log_message(f"Исследование '{research.name}' завершено!")
            self.play_sound('click')
        else:
            self.add_log_message("Недостаточно средств")

    def build_infrastructure(self, index):
        if index >= len(self.infrastructure_objects) or self.infrastructure_objects[index].built:
            return
        obj = self.infrastructure_objects[index]
        if self.economy.budget >= obj.cost:
            self.economy.budget -= obj.cost
            obj.built = True
            if "opex" in obj.effect:
                self.economy.infrastructure += 1
            self.add_log_message(f"Построено: {obj.name}")
            self.play_sound('click')
        else:
            self.add_log_message("Недостаточно средств")

    def hire_employee(self, index):
        if index >= len(self.available_employees) or self.available_employees[index].hired:
            return
        emp = self.available_employees[index]
        if self.economy.budget >= emp.salary * 12:
            self.economy.budget -= emp.salary * 12
            emp.hired = True
            self.employees.append(emp)
            self.add_log_message(f"Нанят: {emp.name}")
            self.play_sound('click')
        else:
            self.add_log_message("Недостаточно средств")

    def open_achievements(self):
        self.play_sound('click')
        self.achievements_window_open = True

    def return_to_menu(self):
        self.play_sound('click')
        self.state = GameState.MENU
        self.drilling_mode = False
        self.well_panel_open = False
        self.drilling_window_open = False
        self.event_window_open = False
        self.graph_window_open = False
        self.loan_window_open = False
        self.achievements_window_open = False
        self.research_window_open = False
        self.infrastructure_window_open = False
        self.employees_window_open = False
        self.current_selected_well = None
        self.current_event = None
        self.current_drilling_zone = None
        self.graph_well = None
        self.current_zone = None
        self.loan_window_just_opened = False
        self.event_window_just_opened = False
        self.research_window_just_opened = False
        self.infrastructure_window_just_opened = False
        self.employees_window_just_opened = False
        self.init_menu()

    def load_game_menu(self):
        if os.path.exists("savegame.json"):
            self.load_game()
            self.state = GameState.PLAYING
            self.create_game_buttons()
        else:
            self.add_log_message("Нет сохранения")

    def quit_game(self):
        self.running = False

    def open_loan_window(self):
        amount = random.randint(20, 100) * 1_000_000
        months = random.choice([6, 12, 24])
        rate = self.economy.loan_interest
        self.current_loan_offer = Loan(amount, months, rate)
        self.loan_window_open = True
        self.loan_window_just_opened = True
        self.add_log_message("Открыто окно кредита")
        self.play_sound('click')

    def generate_report_pdf(self):
        if sys.platform == 'emscripten':
            self.add_log_message("PDF-отчёты недоступны в браузере")
            return
        filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        result = generate_detailed_report(self, filename)
        if result:
            self.add_log_message(f"Отчёт сохранён: {filename}")
        else:
            self.add_log_message("Ошибка создания отчёта")

    def generate_certificate_pdf(self):
        if sys.platform == 'emscripten':
            self.add_log_message("Сертификаты недоступны в браузере")
            return
        filename = f"certificate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        result = generate_certificate(self, "Игрок", filename)
        if result:
            self.add_log_message(f"Сертификат сохранён: {filename}")
        else:
            self.add_log_message("Ошибка создания сертификата")

    # ================== Проверка открытых окон ==================
    def is_any_window_open(self):
        return (self.drilling_window_open or self.well_panel_open or
                self.event_window_open or self.graph_window_open or
                self.loan_window_open or self.achievements_window_open or
                self.research_window_open or self.infrastructure_window_open or
                self.employees_window_open)

    # ================== Обработка событий ==================
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and self.state == GameState.PLAYING:
                    self.next_month()
                elif event.key == pygame.K_ESCAPE:
                    if self.state == GameState.PLAYING:
                        self.state = GameState.PAUSED
                    elif self.state == GameState.PAUSED:
                        self.state = GameState.PLAYING
                    elif self.state == GameState.ZONE_DETAIL:
                        self.state = GameState.PLAYING
                        self.current_zone = None
                    elif self.state in [GameState.GAME_OVER, GameState.WIN]:
                        self.state = GameState.MENU
                        self.init_menu()
                elif event.key == pygame.K_p and self.state == GameState.PLAYING:
                    self.state = GameState.PAUSED if self.state == GameState.PLAYING else GameState.PLAYING
                elif event.key == pygame.K_r and self.state == GameState.PLAYING:
                    self.open_research_window()
                elif event.key == pygame.K_i and self.state == GameState.PLAYING:
                    self.open_infrastructure_window()
                elif event.key == pygame.K_e and self.state == GameState.PLAYING:
                    self.open_employees_window()
                elif event.key == pygame.K_l and self.state == GameState.PLAYING:
                    self.open_loan_window()
                elif event.key == pygame.K_b and self.state == GameState.PLAYING:
                    self.enter_drilling_mode()
                elif event.key == pygame.K_n and self.state == GameState.PLAYING:
                    self.next_month()

            if self.state == GameState.MENU:
                for btn in self.menu_buttons:
                    btn.handle_event(event)
                if self.show_diff_buttons:
                    for btn in self.diff_buttons:
                        btn.handle_event(event)

            elif self.state == GameState.SETTINGS:
                for btn in self.settings_buttons:
                    btn.handle_event(event)

            elif self.state == GameState.ZONE_DETAIL:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    back_rect = pygame.Rect(SCREEN_WIDTH-220, 20, 200, 40)
                    if back_rect.collidepoint(event.pos):
                        self.state = GameState.PLAYING
                        self.current_zone = None
                        return
                    if self.current_zone:
                        for well in self.current_zone.wells:
                            sx, sy = self.world_to_screen(well.pos[0], well.pos[1])
                            if math.dist((sx, sy), event.pos) < 20:
                                self.open_well_panel(well)
                                break
                if self.well_panel_open and self.current_selected_well:
                    self.handle_well_panel(event)
                elif self.graph_window_open and self.graph_well:
                    self.handle_graph_window(event)

            elif self.state in [GameState.PLAYING, GameState.PAUSED, GameState.GAME_OVER, GameState.WIN]:
                for btn in self.buttons:
                    btn.handle_event(event)

                if self.drilling_window_open:
                    self.handle_drilling_window(event)
                elif self.well_panel_open and self.current_selected_well:
                    self.handle_well_panel(event)
                elif self.event_window_open and self.current_event:
                    self.handle_event_window(event)
                elif self.graph_window_open and self.graph_well:
                    self.handle_graph_window(event)
                elif self.loan_window_open:
                    self.handle_loan_window(event)
                elif self.achievements_window_open:
                    self.handle_achievements_window(event)
                elif self.research_window_open:
                    self.handle_research_window(event)
                elif self.infrastructure_window_open:
                    self.handle_infrastructure_window(event)
                elif self.employees_window_open:
                    self.handle_employees_window(event)
                else:
                    if self.state == GameState.PLAYING:
                        if event.type == pygame.MOUSEBUTTONDOWN:
                            if event.button == 4:
                                self.camera_zoom *= 1.1
                                self.camera_zoom = min(2.0, self.camera_zoom)
                            elif event.button == 5:
                                self.camera_zoom /= 1.1
                                self.camera_zoom = max(0.5, self.camera_zoom)
                            elif event.button == 2:
                                self.dragging = True
                                self.drag_start = event.pos
                            elif event.button == 1:
                                world_x, world_y = self.screen_to_world(*event.pos)
                                if self.drilling_mode:
                                    for zone in self.zones:
                                        if zone.rect.collidepoint(world_x, world_y):
                                            self.open_drilling_window(zone, (world_x, world_y))
                                            break
                                else:
                                    clicked_well = None
                                    for well in self.wells:
                                        if well.owner == 'player' and math.dist(well.pos, (world_x, world_y)) < 20 / self.camera_zoom:
                                            self.open_well_panel(well)
                                            clicked_well = well
                                            break
                                    if not clicked_well:
                                        for zone in self.zones:
                                            if zone.rect.collidepoint(world_x, world_y):
                                                self.state = GameState.ZONE_DETAIL
                                                self.current_zone = zone
                                                break
                        elif event.type == pygame.MOUSEBUTTONUP:
                            if event.button == 2:
                                self.dragging = False
                        elif event.type == pygame.MOUSEMOTION:
                            if self.dragging:
                                dx, dy = event.pos[0] - self.drag_start[0], event.pos[1] - self.drag_start[1]
                                self.camera_offset[0] += dx / self.camera_zoom
                                self.camera_offset[1] += dy / self.camera_zoom
                                self.drag_start = event.pos
                                self.camera_offset[0] = max(-500, min(500, self.camera_offset[0]))
                                self.camera_offset[1] = max(-500, min(500, self.camera_offset[1]))

    # ================== Методы окон (без изменений) ==================
    def get_drilling_window_buttons(self, x, y):
        buttons = []
        yi = y + 70 + 4*25 + 10
        btn_vert = pygame.Rect(x+200, yi-5, 120, 30)
        btn_hor = pygame.Rect(x+330, yi-5, 120, 30)
        buttons.append(('well_type', btn_vert, 0))
        buttons.append(('well_type', btn_hor, 1))

        yi += 45
        for i in range(4):
            btn = pygame.Rect(x+20 + i*130, yi+25, 120, 30)
            buttons.append(('completion', btn, i))

        yi += 75
        frack_rect = pygame.Rect(x+20, yi, 20, 20)
        research_rect = pygame.Rect(x+300, yi, 20, 20)
        buttons.append(('frack', frack_rect, None))
        buttons.append(('research', research_rect, None))

        yi += 50
        btn_drill = pygame.Rect(x+150, yi, 120, 40)
        btn_cancel = pygame.Rect(x+300, yi, 120, 40)
        buttons.append(('drill', btn_drill, None))
        buttons.append(('cancel', btn_cancel, None))

        return buttons

    def handle_drilling_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 550, 450
        x = min(self.drilling_window_pos[0], SCREEN_WIDTH - w - 20)
        y = min(self.drilling_window_pos[1], SCREEN_HEIGHT - h - 20)
        mouse_pos = event.pos
        if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
            self.drilling_window_open = False
            return
        buttons = self.get_drilling_window_buttons(x, y)
        for btn_type, rect, value in buttons:
            if rect.collidepoint(mouse_pos):
                if btn_type == 'well_type':
                    self.drill_well_type = value
                elif btn_type == 'completion':
                    self.drill_completion = value
                elif btn_type == 'frack':
                    self.drill_frack = not self.drill_frack
                elif btn_type == 'research':
                    self.drill_research = not self.drill_research
                elif btn_type == 'drill':
                    self.complete_drilling()
                elif btn_type == 'cancel':
                    self.drilling_window_open = False
                break

    def get_well_panel_buttons(self, x, y):
        buttons = []
        yi = y + 40 + 9*25
        btn_frack = pygame.Rect(x+20, yi, 100, 35)
        btn_convert = pygame.Rect(x+130, yi, 100, 35)
        btn_treatment = pygame.Rect(x+240, yi, 100, 35)
        btn_abandon = pygame.Rect(x+20, yi+45, 100, 35)
        btn_graph = pygame.Rect(x+130, yi+45, 100, 35)
        btn_close = pygame.Rect(x+350, y+10, 35, 35)

        buttons.append(('frack', btn_frack))
        buttons.append(('convert', btn_convert))
        buttons.append(('treatment', btn_treatment))
        buttons.append(('abandon', btn_abandon))
        buttons.append(('graph', btn_graph))
        buttons.append(('close', btn_close))
        return buttons

    def handle_well_panel(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 400, 400
        x, y = 300, 150
        mouse_pos = event.pos
        if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
            self.well_panel_open = False
            return
        buttons = self.get_well_panel_buttons(x, y)
        for btn_type, rect in buttons:
            if rect.collidepoint(mouse_pos):
                if btn_type == 'frack':
                    self.frack_well(self.current_selected_well)
                elif btn_type == 'convert':
                    self.convert_well(self.current_selected_well)
                elif btn_type == 'treatment':
                    self.treat_well(self.current_selected_well)
                elif btn_type == 'abandon':
                    self.abandon_well(self.current_selected_well)
                elif btn_type == 'graph':
                    self.open_graph_window(self.current_selected_well)
                elif btn_type == 'close':
                    self.well_panel_open = False
                break

    def handle_event_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 600, 350
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if self.event_window_just_opened:
            self.event_window_just_opened = False
        else:
            if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
                self.event_window_open = False
                self.current_event = None
                return
        for i in range(len(self.current_event.choices)):
            btn = pygame.Rect(x+50 + i*170, y+h-70, 160, 40)
            if btn.collidepoint(mouse_pos):
                self.apply_event_choice(i)
                break

    def handle_graph_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 500, 300
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
            self.graph_window_open = False
            return
        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        if btn_close.collidepoint(mouse_pos):
            self.graph_window_open = False

    def handle_loan_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 500, 300
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if self.loan_window_just_opened:
            self.loan_window_just_opened = False
        else:
            if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
                self.loan_window_open = False
                return
        btn_accept = pygame.Rect(x+100, y+h-80, 120, 40)
        btn_decline = pygame.Rect(x+280, y+h-80, 120, 40)
        if btn_accept.collidepoint(mouse_pos):
            self.accept_loan()
        elif btn_decline.collidepoint(mouse_pos):
            self.loan_window_open = False

    def handle_research_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 500, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if self.research_window_just_opened:
            self.research_window_just_opened = False
        else:
            if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
                self.research_window_open = False
                return
        for i, res in enumerate(self.researches):
            btn = pygame.Rect(x+50, y+80 + i*50, 150, 40)
            if btn.collidepoint(mouse_pos):
                self.research(i)
                break
        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        if btn_close.collidepoint(mouse_pos):
            self.research_window_open = False

    def handle_infrastructure_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 500, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if self.infrastructure_window_just_opened:
            self.infrastructure_window_just_opened = False
        else:
            if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
                self.infrastructure_window_open = False
                return
        for i, obj in enumerate(self.infrastructure_objects):
            btn = pygame.Rect(x+50, y+80 + i*50, 150, 40)
            if btn.collidepoint(mouse_pos):
                self.build_infrastructure(i)
                break
        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        if btn_close.collidepoint(mouse_pos):
            self.infrastructure_window_open = False

    def handle_employees_window(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        w, h = 600, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        mouse_pos = event.pos
        if self.employees_window_just_opened:
            self.employees_window_just_opened = False
        else:
            if not (x <= mouse_pos[0] <= x+w and y <= mouse_pos[1] <= y+h):
                self.employees_window_open = False
                return
        for i, emp in enumerate(self.available_employees):
            btn = pygame.Rect(x+50, y+80 + i*60, 200, 40)
            if btn.collidepoint(mouse_pos):
                self.hire_employee(i)
                break
        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        if btn_close.collidepoint(mouse_pos):
            self.employees_window_open = False

    def handle_achievements_window(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.achievements_window_open = False

    # ================== Игровая логика ==================
    def next_month(self):
        if self.state != GameState.PLAYING:
            return

        for well in self.wells:
            if well.owner == 'player' and well.status == WellStatus.ACTIVE:
                decline = well.oil_rate * 0.005 / (1 + 0.1 * len([e for e in self.employees if e.type == EmployeeType.ENGINEER]))
                well.reservoir_pressure -= decline
                if well.reservoir_pressure < 0.1:
                    well.reservoir_pressure = 0.1
                well.water_cut += random.uniform(0.001, 0.005) / (1 + 0.1 * len([e for e in self.employees if e.type == EmployeeType.GEOLOGIST]))
                if well.water_cut > 0.95:
                    well.water_cut = 0.95
                produced = well.oil_rate
                well.total_oil += produced
                well.oil_history.append(well.oil_rate)
                well.water_history.append(well.water_cut)

        for comp in self.competitors:
            comp.act(self.zones, self.wells, self)

        total_oil = sum(w.oil_rate for w in self.wells if w.status == WellStatus.ACTIVE and w.owner == 'player')
        total_comp_oil = sum(w.oil_rate for w in self.wells if w.status == WellStatus.ACTIVE and w.owner != 'player')
        global_oil = total_oil + total_comp_oil

        barrels = total_oil * 7.33
        revenue = barrels * self.economy.oil_price * 90

        opex_base = sum(w.opex for w in self.wells if w.status == WellStatus.ACTIVE and w.owner == 'player')
        opex = opex_base * (1 - 0.05 * self.economy.infrastructure) * (1 - 0.03 * len([e for e in self.employees if e.type == EmployeeType.MANAGER]))

        taxes = revenue * self.economy.tax_rate
        self.economy.total_taxes += taxes

        fines = 0
        for well in self.wells:
            if well.owner == 'player' and well.status == WellStatus.ACTIVE and well.gas_flare:
                fines += 200_000 * self.economy.fine_mult
        self.economy.total_fines += fines
        self.economy.eco_score -= fines / 1_000_000

        interest = 0
        for loan in self.active_loans[:]:
            interest += loan.amount * loan.interest_rate / 12
            loan.months -= 1
            if loan.months <= 0:
                self.active_loans.remove(loan)
        self.economy.total_interest += interest

        costs = self.economy.fixed_costs + opex + taxes + fines + interest
        profit = revenue - costs
        self.economy.budget += profit
        self.economy.profit_history.append(profit)

        if self.economy.market_shock_timer <= 0:
            if random.random() < 0.1:
                shock = random.choice([-20, -10, 10, 20])
                self.economy.oil_price += shock
                self.economy.oil_price = max(25, min(130, self.economy.oil_price))
                self.add_log_message(f"Рыночный шок! Цена изменилась на {shock} $/барр")
                self.economy.market_shock_timer = random.randint(6, 18)
        else:
            self.economy.market_shock_timer -= 1

        self.economy.oil_price_trend += random.uniform(-0.5, 0.5)
        self.economy.oil_price_trend = max(-5, min(5, self.economy.oil_price_trend))
        self.economy.oil_price += self.economy.oil_price_trend + random.uniform(-2, 2)
        self.economy.oil_price = max(25, min(130, self.economy.oil_price))

        event = self.event_manager.get_random_event()
        if event:
            self.current_event = event
            self.event_window_open = True
            self.event_window_just_opened = True
            self.add_log_message(f"Событие: {event.name}")
            self.play_sound('event')

        self.date_month += 1
        if self.date_month > 12:
            self.date_month = 1
            self.date_year += 1
            license_tax = len(self.zones) * 1_000_000
            self.economy.budget -= license_tax
            self.add_log_message(f"Уплачен налог на лицензии: {license_tax:,.0f} руб.")

        self.check_achievements()

        if self.economy.budget < 0:
            self.game_over_reason = "Банкротство!"
            self.state = GameState.GAME_OVER
            self.play_sound('lose')
        elif self.economy.budget >= self.win_target:
            self.state = GameState.WIN
            self.play_sound('win')

        self.add_log_message(f"Месяц {self.date_month:02d}/{self.date_year} завершён. Прибыль: {profit:,.0f} руб.")

    def check_achievements(self):
        if not self.achievements['first_well']['unlocked'] and any(w.owner == 'player' for w in self.wells):
            self.achievements['first_well']['unlocked'] = True
            self.add_log_message(f"Достижение: {self.achievements['first_well']['name']}")

        player_wells = [w for w in self.wells if w.owner == 'player']
        if not self.achievements['ten_wells']['unlocked'] and len(player_wells) >= 10:
            self.achievements['ten_wells']['unlocked'] = True
            self.add_log_message(f"Достижение: {self.achievements['ten_wells']['name']}")

        if not self.achievements['millionaire']['unlocked'] and self.economy.budget >= 1_000_000:
            self.achievements['millionaire']['unlocked'] = True
            self.add_log_message(f"Достижение: {self.achievements['millionaire']['name']}")

        if not self.achievements['billionaire']['unlocked'] and self.economy.budget >= 1_000_000_000:
            self.achievements['billionaire']['unlocked'] = True
            self.add_log_message(f"Достижение: {self.achievements['billionaire']['name']}")

        if not self.achievements['eco_friendly']['unlocked'] and self.economy.eco_score >= 150:
            self.achievements['eco_friendly']['unlocked'] = True
            self.add_log_message(f"Достижение: {self.achievements['eco_friendly']['name']}")

        if not self.achievements['monopolist']['unlocked']:
            all_zones_occupied = all(any(w.owner == 'player' for w in z.wells) for z in self.zones)
            if all_zones_occupied:
                self.achievements['monopolist']['unlocked'] = True
                self.add_log_message(f"Достижение: {self.achievements['monopolist']['name']}")

    def accept_loan(self):
        if hasattr(self, 'current_loan_offer'):
            self.active_loans.append(self.current_loan_offer)
            self.economy.budget += self.current_loan_offer.amount
            self.add_log_message(f"Кредит {self.current_loan_offer.amount:,.0f} руб. получен.")
            self.current_loan_offer = None
        self.loan_window_open = False

    def enter_drilling_mode(self):
        self.drilling_mode = True
        self.add_log_message("Режим бурения: выберите свободную зону на карте.")
        self.play_sound('click')

    def open_drilling_window(self, zone, pos):
        self.drilling_mode = False
        self.drilling_window_open = True
        self.current_drilling_zone = zone
        screen_pos = self.world_to_screen(*pos)
        self.drilling_window_pos = screen_pos
        self.drill_well_type = 0
        self.drill_completion = 0
        self.drill_frack = False
        self.drill_research = False

    def complete_drilling(self):
        base_cost = 10_000_000
        type_mult = 2.0 if self.drill_well_type == 1 else 1.0
        comp_cost = [1_000_000, 5_000_000, 3_000_000, 8_000_000][self.drill_completion]
        frack_cost = 4_000_000 if self.drill_frack else 0
        research_cost = 2_000_000 if self.drill_research else 0
        total_cost = base_cost * type_mult + comp_cost + frack_cost + research_cost
        total_cost = int(total_cost * (1 - 0.05 * len([e for e in self.employees if e.type == EmployeeType.ENGINEER])))

        if self.economy.budget < total_cost:
            self.add_log_message("Недостаточно средств для бурения.")
            self.drilling_window_open = False
            return

        self.economy.budget -= total_cost

        zone = self.current_drilling_zone
        well_x = zone.rect.x + random.randint(20, zone.rect.w - 20)
        well_y = zone.rect.y + random.randint(20, zone.rect.h - 20)
        new_well = Well(
            well_id=self.next_well_id,
            name=f"Скв.{self.next_well_id}",
            pos=(well_x, well_y),
            zone_type=zone.zone_type,
            completion=WellCompletion(self.drill_completion+1),
            is_fracked=self.drill_frack,
            status=WellStatus.ACTIVE,
            owner='player'
        )
        self.next_well_id += 1
        zone.wells.append(new_well)
        self.wells.append(new_well)

        if self.drill_research:
            new_well.initial_pressure = zone.initial_pressure
            new_well.reservoir_pressure = zone.initial_pressure
            new_well.oil_rate = zone.potential_reserves * 0.12 * (1.2 if self.drill_well_type == 1 else 1.0)
            new_well.oil_rate *= (1 + 0.1 * len([e for e in self.employees if e.type == EmployeeType.GEOLOGIST]))
            new_well.water_cut = 0.0
            if random.random() < zone.risk_factor * 0.5:
                new_well.status = WellStatus.ACCIDENT
                self.add_log_message("Авария при бурении! Скважина повреждена.")
        else:
            new_well.initial_pressure = random.uniform(zone.initial_pressure*0.8, zone.initial_pressure*1.2)
            new_well.reservoir_pressure = new_well.initial_pressure
            new_well.oil_rate = random.uniform(zone.potential_reserves*0.05, zone.potential_reserves*0.15) * (1.2 if self.drill_well_type == 1 else 1.0)
            new_well.oil_rate *= (1 + 0.1 * len([e for e in self.employees if e.type == EmployeeType.GEOLOGIST]))
            new_well.water_cut = random.uniform(0, 0.3)
            if random.random() < zone.risk_factor:
                new_well.status = WellStatus.ACCIDENT
                self.add_log_message("Авария при бурении! Скважина повреждена.")

        new_well.opex = comp_cost * 0.1
        new_well.oil_history.append(new_well.oil_rate)
        new_well.water_history.append(new_well.water_cut)

        self.add_log_message(f"Пробурена {new_well.name}")
        self.drilling_window_open = False
        self.play_sound('drill')

    def open_well_panel(self, well):
        self.current_selected_well = well
        self.well_panel_open = True

    def frack_well(self, well):
        if well.is_fracked:
            self.add_log_message("ГРП уже проводился.")
            return
        cost = 4_000_000
        if self.economy.budget < cost:
            self.add_log_message("Недостаточно средств.")
            return
        self.economy.budget -= cost
        well.is_fracked = True
        well.oil_rate *= 1.5
        well.oil_history.append(well.oil_rate)
        self.add_log_message(f"ГРП на {well.name} выполнен.")
        self.play_sound('click')

    def convert_well(self, well):
        options = list(WellCompletion)
        idx = options.index(well.completion)
        new_idx = (idx + 1) % len(options)
        well.completion = options[new_idx]
        base_opex = [200_000, 500_000, 300_000, 800_000][new_idx]
        well.opex = base_opex
        well.oil_rate *= 1.1
        self.add_log_message(f"{well.name} переведена на {well.completion.name}.")

    def treat_well(self, well):
        cost = 2_000_000
        if self.economy.budget < cost:
            self.add_log_message("Недостаточно средств.")
            return
        self.economy.budget -= cost
        well.oil_rate *= 1.2
        well.water_cut *= 0.9
        well.oil_history.append(well.oil_rate)
        well.water_history.append(well.water_cut)
        self.add_log_message(f"Обработка ПЗС на {well.name} выполнена.")

    def abandon_well(self, well):
        well.status = WellStatus.ABANDONED
        for zone in self.zones:
            if well in zone.wells:
                zone.wells.remove(well)
                break
        self.add_log_message(f"{well.name} законсервирована.")

    def open_graph_window(self, well):
        self.graph_well = well
        self.graph_window_open = True

    def apply_event_choice(self, choice_idx):
        choice = self.current_event.choices[choice_idx]
        budget_effect, oil_mult, eco_effect, msg = choice[1], choice[2], choice[3], choice[4]
        self.economy.budget += budget_effect
        self.economy.eco_score += eco_effect
        if oil_mult != 1.0:
            for well in self.wells:
                if well.owner == 'player' and well.status == WellStatus.ACTIVE:
                    well.oil_rate *= oil_mult
        if self.current_event.name == "Кредитное предложение" and choice_idx == 0:
            loan = Loan(50_000_000, 12, self.economy.loan_interest)
            self.active_loans.append(loan)
        self.add_log_message(msg)
        self.event_window_open = False
        self.current_event = None

    def add_log_message(self, msg):
        self.message_log.append(msg)
        if len(self.message_log) > 50:
            self.message_log.pop(0)

    def save_game(self):
        data = {
            'date_year': self.date_year,
            'date_month': self.date_month,
            'economy': self.economy.to_dict(),
            'wells': [w.to_dict() for w in self.wells],
            'next_well_id': self.next_well_id,
            'message_log': self.message_log,
            'difficulty': self.difficulty,
            'competitors': [{'name': c.name, 'budget': c.budget} for c in self.competitors],
            'loans': [{'amount': l.amount, 'months': l.months, 'rate': l.interest_rate} for l in self.active_loans],
            'achievements': self.achievements,
            'camera_offset': self.camera_offset,
            'camera_zoom': self.camera_zoom,
            'zones': [{'rect': [z.rect.x, z.rect.y, z.rect.w, z.rect.h],
                       'wells': [w.id for w in z.wells]} for z in self.zones],
            'researches': [r.to_dict() for r in self.researches],
            'infrastructure': [inf.to_dict() for inf in self.infrastructure_objects],
            'employees': [e.to_dict() for e in self.employees],
            'available_employees': [e.to_dict() for e in self.available_employees]
        }
        try:
            with open("savegame.json", 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            self.add_log_message("Игра сохранена.")
        except Exception as e:
            self.add_log_message(f"Ошибка сохранения: {e}")

    def load_game(self):
        if not os.path.exists("savegame.json"):
            self.add_log_message("Файл сохранения не найден.")
            return
        try:
            with open("savegame.json", 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.date_year = data['date_year']
            self.date_month = data['date_month']
            self.economy = Economy.from_dict(data['economy'], data.get('difficulty', 'medium'))
            self.wells = [Well.from_dict(w) for w in data['wells']]
            self.next_well_id = data.get('next_well_id', len(self.wells)+1)
            self.message_log = data.get('message_log', [])
            self.difficulty = data.get('difficulty', 'medium')
            self.event_manager = EventManager(self.difficulty)
            self.win_target = DIFFICULTY[self.difficulty]['win_budget']
            self.zones = generate_zones(SCREEN_WIDTH, SCREEN_HEIGHT)
            for well in self.wells:
                for zone in self.zones:
                    if zone.rect.collidepoint(well.pos):
                        zone.wells.append(well)
                        break

            self.competitors = []
            for cd in data.get('competitors', []):
                comp = Competitor(cd['name'], COLOR_COMPETITOR, 0.3)
                comp.budget = cd['budget']
                self.competitors.append(comp)
            self.active_loans = []
            for ld in data.get('loans', []):
                loan = Loan(ld['amount'], ld['months'], ld['rate'])
                self.active_loans.append(loan)
            self.achievements = data.get('achievements', ACHIEVEMENTS.copy())
            self.camera_offset = data.get('camera_offset', [0, 0])
            self.camera_zoom = data.get('camera_zoom', 1.0)

            self.researches = [Research.from_dict(r) for r in data.get('researches', [])]
            if not self.researches:
                self.init_researches()
            self.infrastructure_objects = [Infrastructure.from_dict(inf) for inf in data.get('infrastructure', [])]
            if not self.infrastructure_objects:
                self.init_infrastructure()
            self.employees = [Employee.from_dict(e) for e in data.get('employees', [])]
            self.available_employees = [Employee.from_dict(e) for e in data.get('available_employees', [])]
            if not self.available_employees:
                self.init_employees()

            self.add_log_message("Игра загружена.")
            self.state = GameState.PLAYING
        except Exception as e:
            self.add_log_message(f"Ошибка загрузки: {e}")

    # ================== Отрисовка мира ==================
    def draw_world(self):
        grid_step = 50
        left_world, top_world = self.screen_to_world(0, 0)
        right_world, bottom_world = self.screen_to_world(SCREEN_WIDTH, SCREEN_HEIGHT)

        x = int(left_world // grid_step) * grid_step
        while x <= right_world:
            screen_x, _ = self.world_to_screen(x, 0)
            if 0 <= screen_x <= SCREEN_WIDTH:
                pygame.draw.line(self.screen, (100, 100, 120, 50), (screen_x, 0), (screen_x, SCREEN_HEIGHT), 1)
            x += grid_step

        y = int(top_world // grid_step) * grid_step
        while y <= bottom_world:
            _, screen_y = self.world_to_screen(0, y)
            if 0 <= screen_y <= SCREEN_HEIGHT:
                pygame.draw.line(self.screen, (100, 100, 120, 50), (0, screen_y), (SCREEN_WIDTH, screen_y), 1)
            y += grid_step

        for zone in self.zones:
            zone.update_pulse(self.settings.animations_enabled)
            screen_rect = pygame.Rect(
                self.world_to_screen(zone.rect.x, zone.rect.y)[0],
                self.world_to_screen(zone.rect.x, zone.rect.y)[1],
                zone.rect.w * self.camera_zoom,
                zone.rect.h * self.camera_zoom
            )
            scaled_surf = pygame.transform.scale(zone.surface, (screen_rect.w, screen_rect.h))
            self.screen.blit(scaled_surf, screen_rect.topleft)
            pygame.draw.rect(self.screen, COLOR_ZONE_BORDER, screen_rect, 2)

            if zone.wells:
                center = self.world_to_screen(zone.rect.centerx, zone.rect.centery)
                count_surf = self.small_font.render(str(len(zone.wells)), True, COLOR_TEXT)
                self.screen.blit(count_surf, (center[0]-5, center[1]-10))

        for well in self.wells:
            screen_pos = self.world_to_screen(well.pos[0], well.pos[1])
            if well.owner != 'player':
                color = COLOR_COMPETITOR
                radius = int(8 * self.camera_zoom)
            else:
                color = {
                    WellStatus.ACTIVE: COLOR_WELL_ACTIVE,
                    WellStatus.IDLE: COLOR_WELL_IDLE,
                    WellStatus.ACCIDENT: COLOR_WELL_ACCIDENT,
                    WellStatus.ABANDONED: COLOR_WELL_ABANDONED
                }[well.status]
                radius = int(10 * self.camera_zoom)

            if self.settings.animations_enabled and well.owner == 'player':
                scale = 1.0 + 0.1 * math.sin(pygame.time.get_ticks() * 0.005 + well.animation_offset)
                radius = int(radius * scale)

            pygame.draw.circle(self.screen, color, screen_pos, radius)
            pygame.draw.circle(self.screen, (255,255,255), screen_pos, radius, 1)

    # ================== Отрисовка детальной зоны ==================
    def draw_zone_detail(self):
        if not self.current_zone:
            return
        zone = self.current_zone
        self.screen.fill((20, 40, 30))

        if not zone.wells:
            font = self.big_font.render("Куст не разработан", True, COLOR_TEXT)
            self.screen.blit(font, (SCREEN_WIDTH//2 - font.get_width()//2, SCREEN_HEIGHT//2))
        else:
            for well in zone.wells:
                sx, sy = self.world_to_screen(well.pos[0], well.pos[1])
                color = COLOR_WELL_ACTIVE if well.owner == 'player' else COLOR_COMPETITOR
                pygame.draw.circle(self.screen, color, (sx, sy), int(15 * self.camera_zoom))
                name_surf = self.small_font.render(well.name, True, COLOR_TEXT)
                self.screen.blit(name_surf, (sx - 30, sy - 40))
                rate_surf = self.small_font.render(f"{well.oil_rate:.0f} т/мес", True, COLOR_TEXT)
                self.screen.blit(rate_surf, (sx - 30, sy + 20))
                if well.gas_flare:
                    flame_points = [(sx-10, sy-30), (sx+10, sy-30), (sx, sy-50)]
                    pygame.draw.polygon(self.screen, (255, 100, 0), flame_points)

        back_btn = pygame.Rect(SCREEN_WIDTH-220, 20, 200, 40)
        pygame.draw.rect(self.screen, COLOR_BUTTON, back_btn, border_radius=5)
        self.screen.blit(self.font.render("Назад", True, COLOR_TEXT), (SCREEN_WIDTH-180, 25))

    # ================== Отрисовка UI ==================
    def draw(self):
        if self.state == GameState.MENU:
            self.draw_menu()
        elif self.state == GameState.SETTINGS:
            self.draw_settings()
        elif self.state == GameState.PLAYING:
            self.draw_game()
        elif self.state == GameState.PAUSED:
            self.draw_game()
            self.draw_pause()
        elif self.state == GameState.GAME_OVER:
            self.draw_game()
            self.draw_game_over()
        elif self.state == GameState.WIN:
            self.draw_game()
            self.draw_win()
        elif self.state == GameState.ZONE_DETAIL:
            self.draw_zone_detail()

        pygame.display.flip()

    def draw_menu(self):
        self.screen.fill(COLOR_BG_TOP)
        for y in range(SCREEN_HEIGHT):
            r = COLOR_BG_TOP[0] + (COLOR_BG_BOTTOM[0] - COLOR_BG_TOP[0]) * y // SCREEN_HEIGHT
            g = COLOR_BG_TOP[1] + (COLOR_BG_BOTTOM[1] - COLOR_BG_TOP[1]) * y // SCREEN_HEIGHT
            b = COLOR_BG_TOP[2] + (COLOR_BG_BOTTOM[2] - COLOR_BG_TOP[2]) * y // SCREEN_HEIGHT
            pygame.draw.line(self.screen, (r, g, b), (0, y), (SCREEN_WIDTH, y))

        title = self.big_font.render("ДИРЕКТОР МЕСТОРОЖДЕНИЯ", True, COLOR_TEXT)
        self.screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))

        for btn in self.menu_buttons:
            btn.update()
            btn.draw(self.screen)

        if self.show_diff_buttons:
            for btn in self.diff_buttons:
                btn.update()
                btn.draw(self.screen)

    def draw_settings(self):
        self.screen.fill(COLOR_BG_TOP)
        title = self.big_font.render("НАСТРОЙКИ", True, COLOR_TEXT)
        self.screen.blit(title, (SCREEN_WIDTH//2 - title.get_width()//2, 100))
        for btn in self.settings_buttons:
            btn.update()
            btn.draw(self.screen)

    def draw_game(self):
        if self.settings.show_relief and self.relief_map:
            draw_relief_with_biomes(self.screen, self.relief_map, self.biome_map, self.relief_cell_size)
        else:
            for y in range(SCREEN_HEIGHT):
                r = COLOR_BG_TOP[0] + (COLOR_BG_BOTTOM[0] - COLOR_BG_TOP[0]) * y // SCREEN_HEIGHT
                g = COLOR_BG_TOP[1] + (COLOR_BG_BOTTOM[1] - COLOR_BG_TOP[1]) * y // SCREEN_HEIGHT
                b = COLOR_BG_TOP[2] + (COLOR_BG_BOTTOM[2] - COLOR_BG_TOP[2]) * y // SCREEN_HEIGHT
                pygame.draw.line(self.screen, (r, g, b), (0, y), (SCREEN_WIDTH, y))

        self.draw_world()

        panel = pygame.Rect(0, 0, SCREEN_WIDTH, 60)
        pygame.draw.rect(self.screen, COLOR_PANEL, panel)
        pygame.draw.line(self.screen, COLOR_PANEL_LIGHT, (0, 60), (SCREEN_WIDTH, 60), 2)

        texts = [
            f"Бюджет: {self.economy.budget:,.0f} руб.",
            f"Цена: {self.economy.oil_price:.1f} $/барр",
            f"Дата: {self.date_month:02d}/{self.date_year}",
            f"Эко: {self.economy.eco_score:.0f}",
            f"Тех: {self.economy.tech_level}",
            f"Инфра: {self.economy.infrastructure}",
            f"Цель: {self.win_target:,.0f} руб."
        ]
        x = 20
        for t in texts:
            surf = self.font.render(t, True, COLOR_TEXT)
            self.screen.blit(surf, (x, 20))
            x += surf.get_width() + 30

        for btn in self.buttons:
            btn.update()
            btn.draw(self.screen)

        log_rect = pygame.Rect(20, SCREEN_HEIGHT-200, 450, 180)
        pygame.draw.rect(self.screen, COLOR_PANEL, log_rect, border_radius=5)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, log_rect, 2, border_radius=5)
        log_title = self.small_font.render("Лог событий:", True, COLOR_TEXT)
        self.screen.blit(log_title, (log_rect.x+10, log_rect.y+5))
        y = log_rect.y + 30
        for msg in self.message_log[-9:]:
            surf = self.small_font.render(msg, True, COLOR_TEXT_DARK)
            self.screen.blit(surf, (log_rect.x + 10, y))
            y += 18

        if self.drilling_window_open:
            self.draw_drilling_window()
        if self.well_panel_open and self.current_selected_well:
            self.draw_well_panel()
        if self.event_window_open and self.current_event:
            self.draw_event_window()
        if self.graph_window_open and self.graph_well:
            self.draw_graph_window()
        if self.loan_window_open:
            self.draw_loan_window()
        if self.achievements_window_open:
            self.draw_achievements_window()
        if self.research_window_open:
            self.draw_research_window()
        if self.infrastructure_window_open:
            self.draw_infrastructure_window()
        if self.employees_window_open:
            self.draw_employees_window()

    def draw_research_window(self):
        w, h = 500, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("НИОКР", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+15))

        for i, res in enumerate(self.researches):
            color = COLOR_GOLD if res.researched else COLOR_BUTTON
            btn = pygame.Rect(x+50, y+80 + i*50, 150, 40)
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.small_font.render(res.name, True, COLOR_TEXT), (btn.x+10, btn.y+10))
            cost_surf = self.small_font.render(f"{res.cost:,.0f} руб.", True, COLOR_TEXT_DARK)
            self.screen.blit(cost_surf, (x+220, y+90 + i*50))

        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_infrastructure_window(self):
        w, h = 500, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("Строительство", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+15))

        for i, obj in enumerate(self.infrastructure_objects):
            color = COLOR_BUTTON_DISABLED if obj.built else COLOR_BUTTON
            btn = pygame.Rect(x+50, y+80 + i*50, 150, 40)
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.small_font.render(obj.name, True, COLOR_TEXT), (btn.x+10, btn.y+10))
            cost_surf = self.small_font.render(f"{obj.cost:,.0f} руб.", True, COLOR_TEXT_DARK)
            self.screen.blit(cost_surf, (x+220, y+90 + i*50))

        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_employees_window(self):
        w, h = 600, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("Наём сотрудников", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+15))

        for i, emp in enumerate(self.available_employees):
            color = COLOR_BUTTON_DISABLED if emp.hired else COLOR_BUTTON
            btn = pygame.Rect(x+50, y+80 + i*60, 200, 40)
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.small_font.render(emp.name, True, COLOR_TEXT), (btn.x+10, btn.y+10))
            info = f"{emp.type.name} (skill {emp.skill}) {emp.salary:,.0f}/год"
            self.screen.blit(self.small_font.render(info, True, COLOR_TEXT_DARK), (x+260, y+90 + i*60))

        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_well_panel(self):
        w, h = 400, 400
        x, y = 300, 150
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        well = self.current_selected_well
        lines = [
            f"{well.name}",
            f"Дебит: {well.oil_rate:.1f} т/мес",
            f"Обводнённость: {well.water_cut*100:.1f}%",
            f"Давление: {well.reservoir_pressure:.1f} МПа",
            f"Статус: {well.status.name}",
            f"Добыто: {well.total_oil:.0f} т",
            f"Способ: {well.completion.name}",
            f"ГРП: {'да' if well.is_fracked else 'нет'}",
            f"Газ: {'факел' if well.gas_flare else 'утилизация'}"
        ]
        yi = y + 40
        for line in lines:
            surf = self.font.render(line, True, COLOR_TEXT)
            self.screen.blit(surf, (x+20, yi))
            yi += 25

        buttons = self.get_well_panel_buttons(x, y)
        btn_frack, btn_convert, btn_treatment, btn_abandon, btn_graph, btn_close = [b[1] for b in buttons]
        mouse_pos = pygame.mouse.get_pos()
        for btn, text in [(btn_frack, "ГРП"), (btn_convert, "Конверт"), (btn_treatment, "Обраб."),
                          (btn_abandon, "Консерв"), (btn_graph, "График")]:
            hover = btn.collidepoint(mouse_pos)
            color = COLOR_BUTTON_HOVER if hover else COLOR_BUTTON
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.small_font.render(text, True, COLOR_TEXT), (btn.x+10, btn.y+8))

        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_graph_window(self):
        w, h = 500, 300
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_GRAPH_BG, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render(f"График - {self.graph_well.name}", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+15))

        graph_rect = pygame.Rect(x+40, y+60, w-80, h-120)
        pygame.draw.rect(self.screen, (20,20,30), graph_rect)
        pygame.draw.rect(self.screen, COLOR_TEXT_DARK, graph_rect, 1)

        if len(self.graph_well.oil_history) > 1:
            max_rate = max(self.graph_well.oil_history) or 1
            points = []
            for i, val in enumerate(self.graph_well.oil_history[-50:]):
                px = graph_rect.x + (i * graph_rect.w // min(50, len(self.graph_well.oil_history)))
                py = graph_rect.y + graph_rect.h - (val / max_rate) * graph_rect.h
                points.append((px, py))
            if len(points) > 1:
                pygame.draw.lines(self.screen, COLOR_GRAPH, False, points, 2)

        if len(self.graph_well.water_history) > 1:
            max_water = 1.0
            points = []
            for i, val in enumerate(self.graph_well.water_history[-50:]):
                px = graph_rect.x + (i * graph_rect.w // min(50, len(self.graph_well.water_history)))
                py = graph_rect.y + graph_rect.h - val * graph_rect.h
                points.append((px, py))
            if len(points) > 1:
                pygame.draw.lines(self.screen, (255,150,150), False, points, 2)

        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_event_window(self):
        w, h = 600, 350
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        ev = self.current_event
        title = self.big_font.render(ev.name, True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+20))

        words = ev.desc.split(' ')
        lines = []
        current_line = ""
        for word in words:
            test_line = current_line + word + " "
            if self.font.size(test_line)[0] < w - 40:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word + " "
        if current_line:
            lines.append(current_line)

        yi = y + 70
        for line in lines:
            surf = self.font.render(line, True, COLOR_TEXT_DARK)
            self.screen.blit(surf, (x+20, yi))
            yi += 25

        for i, choice in enumerate(ev.choices):
            btn = pygame.Rect(x+50 + i*170, y+h-70, 160, 40)
            hover = btn.collidepoint(pygame.mouse.get_pos())
            color = COLOR_BUTTON_HOVER if hover else COLOR_BUTTON
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.small_font.render(choice[0], True, COLOR_TEXT), (btn.x+10, btn.y+10))

    def draw_loan_window(self):
        w, h = 500, 300
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("Кредитное предложение", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+20))

        loan = self.current_loan_offer
        lines = [
            f"Сумма: {loan.amount:,.0f} руб.",
            f"Срок: {loan.months} мес.",
            f"Ставка: {loan.interest_rate*100:.0f}%",
            f"Ежемесячный платёж: {loan.monthly_payment:,.0f} руб."
        ]
        yi = y + 70
        for line in lines:
            surf = self.font.render(line, True, COLOR_TEXT)
            self.screen.blit(surf, (x+20, yi))
            yi += 25

        btn_accept = pygame.Rect(x+100, y+h-80, 120, 40)
        btn_decline = pygame.Rect(x+280, y+h-80, 120, 40)
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn_accept, border_radius=5)
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn_decline, border_radius=5)
        self.screen.blit(self.font.render("Принять", True, COLOR_TEXT), (btn_accept.x+30, btn_accept.y+10))
        self.screen.blit(self.font.render("Отказ", True, COLOR_TEXT), (btn_decline.x+30, btn_decline.y+10))

    def draw_achievements_window(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0,0,0,200))
        self.screen.blit(overlay, (0,0))

        w, h = 500, 400
        x, y = (SCREEN_WIDTH - w)//2, (SCREEN_HEIGHT - h)//2
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("Достижения", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+15))

        yi = y + 70
        for key, ach in self.achievements.items():
            color = COLOR_GOLD if ach['unlocked'] else COLOR_TEXT_DARK
            text = f"{ach['name']}: {ach['desc']}"
            surf = self.small_font.render(text, True, color)
            self.screen.blit(surf, (x+20, yi))
            yi += 25

        btn_close = pygame.Rect(x+w-50, y+10, 35, 35)
        pygame.draw.rect(self.screen, (200,50,50), btn_close, border_radius=5)
        self.screen.blit(self.font.render("X", True, COLOR_TEXT), (btn_close.x+10, btn_close.y+5))

    def draw_drilling_window(self):
        w, h = 550, 450
        x = min(self.drilling_window_pos[0], SCREEN_WIDTH - w - 20)
        y = min(self.drilling_window_pos[1], SCREEN_HEIGHT - h - 20)
        rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLOR_PANEL, rect, border_radius=10)
        pygame.draw.rect(self.screen, COLOR_PANEL_LIGHT, rect, 3, border_radius=10)

        title = self.big_font.render("Бурение новой скважины", True, COLOR_TEXT)
        self.screen.blit(title, (x+20, y+20))

        zone = self.current_drilling_zone
        info = [
            f"Тип: {zone.zone_type.name}",
            f"Запасы: {zone.potential_reserves} тыс. т",
            f"Давление: {zone.initial_pressure} МПа",
            f"Риск: {zone.risk_factor*100:.0f}%"
        ]
        yi = y + 70
        for line in info:
            surf = self.font.render(line, True, COLOR_TEXT_DARK)
            self.screen.blit(surf, (x+20, yi))
            yi += 25

        buttons = self.get_drilling_window_buttons(x, y)
        btn_vert, btn_hor = buttons[0][1], buttons[1][1]
        color_vert = COLOR_BUTTON_HOVER if self.drill_well_type == 0 else COLOR_BUTTON
        color_hor = COLOR_BUTTON_HOVER if self.drill_well_type == 1 else COLOR_BUTTON
        pygame.draw.rect(self.screen, color_vert, btn_vert, border_radius=5)
        pygame.draw.rect(self.screen, color_hor, btn_hor, border_radius=5)
        self.screen.blit(self.font.render("Верт.", True, COLOR_TEXT), (btn_vert.x+10, btn_vert.y+5))
        self.screen.blit(self.font.render("Гориз.", True, COLOR_TEXT), (btn_hor.x+10, btn_hor.y+5))

        comps = ["Фонтан", "ЭЦН", "ШГН", "Газлифт"]
        for i in range(4):
            btn = buttons[2+i][1]
            color = COLOR_BUTTON_HOVER if self.drill_completion == i else COLOR_BUTTON
            pygame.draw.rect(self.screen, color, btn, border_radius=5)
            self.screen.blit(self.font.render(comps[i], True, COLOR_TEXT), (btn.x+10, btn.y+5))

        frack_rect = buttons[6][1]
        research_rect = buttons[7][1]
        pygame.draw.rect(self.screen, COLOR_BUTTON, frack_rect, 2)
        if self.drill_frack:
            pygame.draw.line(self.screen, COLOR_TEXT, (frack_rect.x+2, frack_rect.y+2), (frack_rect.x+18, frack_rect.y+18), 3)
            pygame.draw.line(self.screen, COLOR_TEXT, (frack_rect.x+18, frack_rect.y+2), (frack_rect.x+2, frack_rect.y+18), 3)
        self.screen.blit(self.font.render("ГРП (+4 млн)", True, COLOR_TEXT), (frack_rect.x+30, frack_rect.y-2))

        pygame.draw.rect(self.screen, COLOR_BUTTON, research_rect, 2)
        if self.drill_research:
            pygame.draw.line(self.screen, COLOR_TEXT, (research_rect.x+2, research_rect.y+2), (research_rect.x+18, research_rect.y+18), 3)
            pygame.draw.line(self.screen, COLOR_TEXT, (research_rect.x+18, research_rect.y+2), (research_rect.x+2, research_rect.y+18), 3)
        self.screen.blit(self.font.render("Исслед. (+2 млн)", True, COLOR_TEXT), (research_rect.x+30, research_rect.y-2))

        btn_drill = buttons[8][1]
        btn_cancel = buttons[9][1]
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn_drill, border_radius=5)
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn_cancel, border_radius=5)
        self.screen.blit(self.font.render("Бурить", True, COLOR_TEXT), (btn_drill.x+30, btn_drill.y+10))
        self.screen.blit(self.font.render("Отмена", True, COLOR_TEXT), (btn_cancel.x+30, btn_cancel.y+10))

    def draw_pause(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0,0,0,128))
        self.screen.blit(overlay, (0,0))
        text = self.big_font.render("ПАУЗА", True, COLOR_TEXT)
        self.screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 30))

    def draw_game_over(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0,0,0,180))
        self.screen.blit(overlay, (0,0))
        text = self.big_font.render("ПОРАЖЕНИЕ", True, (255,100,100))
        self.screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 50))
        reason = self.font.render(self.game_over_reason, True, COLOR_TEXT)
        self.screen.blit(reason, (SCREEN_WIDTH//2 - reason.get_width()//2, SCREEN_HEIGHT//2))
        btn = pygame.Rect(SCREEN_WIDTH//2-100, SCREEN_HEIGHT//2+50, 200, 40)
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn, border_radius=5)
        self.screen.blit(self.font.render("Главное меню", True, COLOR_TEXT), (btn.x+40, btn.y+10))
        if pygame.mouse.get_pressed()[0] and btn.collidepoint(pygame.mouse.get_pos()):
            self.state = GameState.MENU
            self.init_menu()

    def draw_win(self):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0,0,0,180))
        self.screen.blit(overlay, (0,0))
        text = self.big_font.render("ПОБЕДА!", True, (100,255,100))
        self.screen.blit(text, (SCREEN_WIDTH//2 - text.get_width()//2, SCREEN_HEIGHT//2 - 50))
        msg = self.font.render("Вы достигли целевого бюджета", True, COLOR_TEXT)
        self.screen.blit(msg, (SCREEN_WIDTH//2 - msg.get_width()//2, SCREEN_HEIGHT//2))
        btn = pygame.Rect(SCREEN_WIDTH//2-100, SCREEN_HEIGHT//2+50, 200, 40)
        pygame.draw.rect(self.screen, COLOR_BUTTON, btn, border_radius=5)
        self.screen.blit(self.font.render("Главное меню", True, COLOR_TEXT), (btn.x+40, btn.y+10))
        if pygame.mouse.get_pressed()[0] and btn.collidepoint(pygame.mouse.get_pos()):
            self.state = GameState.MENU
            self.init_menu()

    async def run(self):
        while self.running:
            self.handle_events()
            self.draw()
            self.clock.tick(FPS)
            await asyncio.sleep(0)
        pygame.quit()

# ================== Запуск ==================
if __name__ == "__main__":
    asyncio.run(Game().run())